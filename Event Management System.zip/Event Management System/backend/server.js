const express = require("express");
const cors = require("cors");
const crypto = require("crypto");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json({ limit: "20mb" }));

/* =========================================================
   IN-MEMORY DATA
   Nothing is saved to a database or data.json.
   ========================================================= */

const users = [];
const events = [];
const attendees = [];
const activity = [];

/* =========================================================
   HELPERS
   ========================================================= */

function generateId() {
  return crypto.randomUUID();
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");

  const hash = crypto
    .pbkdf2Sync(password, salt, 100000, 64, "sha512")
    .toString("hex");

  return `${salt}:${hash}`;
}

function verifyPassword(password, storedPassword) {
  const parts = storedPassword.split(":");

  if (parts.length !== 2) {
    return false;
  }

  const salt = parts[0];
  const originalHash = parts[1];

  const hash = crypto
    .pbkdf2Sync(password, salt, 100000, 64, "sha512")
    .toString("hex");

  return crypto.timingSafeEqual(
    Buffer.from(hash, "hex"),
    Buffer.from(originalHash, "hex")
  );
}

function calculateStatus(event) {
  const start = new Date(`${event.date}T${event.time || "00:00"}`);

  if (Number.isNaN(start.getTime())) {
    return "Upcoming";
  }

  const duration = Number(event.durationDays) || 1;

  const end = new Date(start);
  end.setDate(end.getDate() + duration);

  const now = new Date();

  if (now < start) {
    return "Upcoming";
  }

  if (now >= start && now < end) {
    return "Ongoing";
  }

  return "Finished";
}

function publicUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
  };
}

function publicEvent(event) {
  return {
    ...event,
    status: calculateStatus(event),
  };
}

function publicAttendee(attendee) {
  const event = events.find((item) => item.id === attendee.eventId);

  return {
    ...attendee,
    eventTitle: event ? event.title : "Unknown Event",
  };
}

function addActivity(action, details) {
  activity.unshift({
    id: generateId(),
    action,
    details,
    createdAt: new Date().toISOString(),
  });

  if (activity.length > 100) {
    activity.splice(100);
  }
}

function cleanText(value) {
  if (value === undefined || value === null) {
    return "";
  }

  return String(value).trim();
}

/* =========================================================
   HEALTH CHECK
   ========================================================= */

app.get("/api/health", (req, res) => {
  res.json({
    success: true,
    message: "School Event Manager backend is running.",
  });
});

/* =========================================================
   AUTH
   ========================================================= */

app.post("/api/auth/register", (req, res) => {
  const name = cleanText(req.body.name);
  const email = cleanText(req.body.email).toLowerCase();
  const password = cleanText(req.body.password);

  if (!name || !email || !password) {
    return res.status(400).json({
      message: "Name, email, and password are required.",
    });
  }

  if (password.length < 6) {
    return res.status(400).json({
      message: "Password must be at least 6 characters.",
    });
  }

  const existingUser = users.find((user) => user.email === email);

  if (existingUser) {
    return res.status(409).json({
      message: "An account with that email already exists.",
    });
  }

  const user = {
    id: generateId(),
    name,
    email,
    password: hashPassword(password),
    role: users.length === 0 ? "Admin" : "Organizer",
    createdAt: new Date().toISOString(),
  };

  users.push(user);

  addActivity(
    "Account Registered",
    `${user.name} created a ${user.role} account.`
  );

  return res.status(201).json({
    message: "Account created successfully.",
    user: publicUser(user),
  });
});

app.post("/api/auth/login", (req, res) => {
  const email = cleanText(req.body.email).toLowerCase();
  const password = cleanText(req.body.password);

  const user = users.find((item) => item.email === email);

  if (!user || !verifyPassword(password, user.password)) {
    return res.status(401).json({
      message: "Invalid email or password.",
    });
  }

  addActivity("User Login", `${user.name} logged into the system.`);

  return res.json({
    message: "Login successful.",
    user: publicUser(user),
  });
});

/* =========================================================
   DASHBOARD
   ========================================================= */

app.get("/api/dashboard", (req, res) => {
  const currentEvents = events.map(publicEvent);

  res.json({
    totalEvents: events.length,
    upcoming: currentEvents.filter((event) => event.status === "Upcoming")
      .length,
    ongoing: currentEvents.filter((event) => event.status === "Ongoing")
      .length,
    finished: currentEvents.filter((event) => event.status === "Finished")
      .length,
    archived: events.filter((event) => event.archived).length,
    active: events.filter((event) => !event.archived).length,
    totalAttendees: attendees.length,
    timedIn: attendees.filter((item) => item.timeInAt).length,
    completedAttendance: attendees.filter(
      (item) => item.timeInAt && item.timeOutAt
    ).length,
  });
});

/* =========================================================
   EVENTS
   ========================================================= */

app.get("/api/events", (req, res) => {
  const result = events.map(publicEvent);

  res.json({
    events: result,
  });
});

app.get("/api/events/:id", (req, res) => {
  const event = events.find((item) => item.id === req.params.id);

  if (!event) {
    return res.status(404).json({
      message: "Event not found.",
    });
  }

  res.json({
    event: publicEvent(event),
  });
});

app.post("/api/events", (req, res) => {
  const title = cleanText(req.body.title);
  const date = cleanText(req.body.date);
  const time = cleanText(req.body.time);
  const location = cleanText(req.body.location);

  if (!title || !date || !time || !location) {
    return res.status(400).json({
      message: "Event name, date, time, and location are required.",
    });
  }

  const durationDays = Math.min(
    3,
    Math.max(1, Number(req.body.durationDays) || 1)
  );

  const event = {
    id: generateId(),
    title,
    date,
    time,
    durationDays,
    location,
    category: cleanText(req.body.category) || "School",
    organizer: cleanText(req.body.organizer),
    capacity: Math.max(0, Number(req.body.capacity) || 0),
    registrationDeadline: cleanText(req.body.registrationDeadline),
    description: cleanText(req.body.description),
    notes: cleanText(req.body.notes),
    poster: cleanText(req.body.poster),
    attachmentName: cleanText(req.body.attachmentName),
    attachmentData: cleanText(req.body.attachmentData),
    archived: false,
    createdBy: cleanText(req.body.createdBy),
    createdByName: cleanText(req.body.createdByName),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  events.push(event);

  addActivity(
    "Event Created",
    `"${event.title}" was created by ${event.createdByName || "a user"}.`
  );

  res.status(201).json({
    message: "Event created successfully.",
    event: publicEvent(event),
  });
});

app.patch("/api/events/:id", (req, res) => {
  const event = events.find((item) => item.id === req.params.id);

  if (!event) {
    return res.status(404).json({
      message: "Event not found.",
    });
  }

  if (event.archived) {
    return res.status(400).json({
      message: "Restore the event before editing it.",
    });
  }

  if (req.body.title !== undefined) {
    event.title = cleanText(req.body.title);
  }

  if (req.body.date !== undefined) {
    event.date = cleanText(req.body.date);
  }

  if (req.body.time !== undefined) {
    event.time = cleanText(req.body.time);
  }

  if (req.body.durationDays !== undefined) {
    event.durationDays = Math.min(
      3,
      Math.max(1, Number(req.body.durationDays) || 1)
    );
  }

  if (req.body.location !== undefined) {
    event.location = cleanText(req.body.location);
  }

  if (req.body.category !== undefined) {
    event.category = cleanText(req.body.category) || "School";
  }

  if (req.body.organizer !== undefined) {
    event.organizer = cleanText(req.body.organizer);
  }

  if (req.body.capacity !== undefined) {
    event.capacity = Math.max(0, Number(req.body.capacity) || 0);
  }

  if (req.body.registrationDeadline !== undefined) {
    event.registrationDeadline = cleanText(req.body.registrationDeadline);
  }

  if (req.body.description !== undefined) {
    event.description = cleanText(req.body.description);
  }

  if (req.body.notes !== undefined) {
    event.notes = cleanText(req.body.notes);
  }

  if (req.body.poster !== undefined) {
    event.poster = cleanText(req.body.poster);
  }

  if (req.body.attachmentName !== undefined) {
    event.attachmentName = cleanText(req.body.attachmentName);
  }

  if (req.body.attachmentData !== undefined) {
    event.attachmentData = cleanText(req.body.attachmentData);
  }

  event.updatedAt = new Date().toISOString();

  addActivity("Event Updated", `"${event.title}" was updated.`);

  res.json({
    message: "Event updated successfully.",
    event: publicEvent(event),
  });
});

app.patch("/api/events/:id/archive", (req, res) => {
  const event = events.find((item) => item.id === req.params.id);

  if (!event) {
    return res.status(404).json({
      message: "Event not found.",
    });
  }

  event.archived = true;
  event.updatedAt = new Date().toISOString();

  addActivity("Event Archived", `"${event.title}" was archived.`);

  res.json({
    message: "Event archived successfully.",
    event: publicEvent(event),
  });
});

app.patch("/api/events/:id/restore", (req, res) => {
  const event = events.find((item) => item.id === req.params.id);

  if (!event) {
    return res.status(404).json({
      message: "Event not found.",
    });
  }

  event.archived = false;
  event.updatedAt = new Date().toISOString();

  addActivity("Event Restored", `"${event.title}" was restored.`);

  res.json({
    message: "Event restored successfully.",
    event: publicEvent(event),
  });
});

app.delete("/api/events/:id", (req, res) => {
  const index = events.findIndex((item) => item.id === req.params.id);

  if (index === -1) {
    return res.status(404).json({
      message: "Event not found.",
    });
  }

  const event = events[index];

  if (!event.archived) {
    return res.status(400).json({
      message:
        "Active events cannot be permanently deleted. Archive the event first.",
    });
  }

  events.splice(index, 1);

  for (let i = attendees.length - 1; i >= 0; i--) {
    if (attendees[i].eventId === event.id) {
      attendees.splice(i, 1);
    }
  }

  addActivity(
    "Event Permanently Deleted",
    `"${event.title}" was permanently deleted.`
  );

  res.json({
    message: "Archived event permanently deleted.",
  });
});

/* =========================================================
   ATTENDEES
   ========================================================= */

app.get("/api/attendees", (req, res) => {
  res.json({
    attendees: attendees.map(publicAttendee),
  });
});

app.post("/api/attendees", (req, res) => {
  const name = cleanText(req.body.name);
  const eventId = cleanText(req.body.eventId);
  const day = Number(req.body.day) || 1;
  const attendancePeriod =
    cleanText(req.body.attendancePeriod).toUpperCase() || "AM";

  if (!name || !eventId) {
    return res.status(400).json({
      message: "Attendee name and event are required.",
    });
  }

  const event = events.find((item) => item.id === eventId);

  if (!event) {
    return res.status(404).json({
      message: "Selected event was not found.",
    });
  }

  if (event.archived) {
    return res.status(400).json({
      message: "You cannot add attendance to an archived event.",
    });
  }

  if (day < 1 || day > event.durationDays) {
    return res.status(400).json({
      message: `This event only has ${event.durationDays} day(s).`,
    });
  }

  if (!["AM", "PM"].includes(attendancePeriod)) {
    return res.status(400).json({
      message: "Attendance period must be AM or PM.",
    });
  }

  if (event.capacity > 0) {
    const count = attendees.filter(
      (item) => item.eventId === event.id
    ).length;

    if (count >= event.capacity) {
      return res.status(400).json({
        message: "This event has reached its attendee capacity.",
      });
    }
  }

  const duplicate = attendees.find(
    (item) =>
      item.eventId === eventId &&
      item.name.toLowerCase() === name.toLowerCase() &&
      item.day === day &&
      item.attendancePeriod === attendancePeriod
  );

  if (duplicate) {
    return res.status(409).json({
      message:
        "This attendee is already listed for this event, day, and period.",
    });
  }

  const attendee = {
    id: generateId(),
    name,
    eventId,
    day,
    attendancePeriod,
    timeInAt: null,
    timeOutAt: null,
    createdAt: new Date().toISOString(),
  };

  attendees.push(attendee);

  addActivity(
    "Attendee Added",
    `${name} was added to "${event.title}" - Day ${day} ${attendancePeriod}.`
  );

  res.status(201).json({
    message: "Attendee added successfully.",
    attendee: publicAttendee(attendee),
  });
});

app.patch("/api/attendees/:id/time-in", (req, res) => {
  const attendee = attendees.find((item) => item.id === req.params.id);

  if (!attendee) {
    return res.status(404).json({
      message: "Attendee not found.",
    });
  }

  if (attendee.timeInAt) {
    return res.status(400).json({
      message: "This attendee has already timed in.",
    });
  }

  attendee.timeInAt =
    cleanText(req.body.timeInAt) || new Date().toISOString();

  const event = events.find((item) => item.id === attendee.eventId);

  addActivity(
    "Time In Recorded",
    `${attendee.name} timed in for "${event?.title || "an event"}".`
  );

  res.json({
    message: "Time In recorded.",
    attendee: publicAttendee(attendee),
  });
});

app.patch("/api/attendees/:id/time-out", (req, res) => {
  const attendee = attendees.find((item) => item.id === req.params.id);

  if (!attendee) {
    return res.status(404).json({
      message: "Attendee not found.",
    });
  }

  if (!attendee.timeInAt) {
    return res.status(400).json({
      message: "Time In must be recorded before Time Out.",
    });
  }

  if (attendee.timeOutAt) {
    return res.status(400).json({
      message: "This attendee has already timed out.",
    });
  }

  const timeOutAt = cleanText(req.body.timeOutAt);

  if (!timeOutAt) {
    return res.status(400).json({
      message: "Time Out date and time are required.",
    });
  }

  const timeOutDate = new Date(timeOutAt);
  const timeInDate = new Date(attendee.timeInAt);

  if (
    Number.isNaN(timeOutDate.getTime()) ||
    Number.isNaN(timeInDate.getTime())
  ) {
    return res.status(400).json({
      message: "Invalid attendance date/time.",
    });
  }

  if (timeOutDate < timeInDate) {
    return res.status(400).json({
      message: "Time Out cannot be earlier than Time In.",
    });
  }

  attendee.timeOutAt = timeOutDate.toISOString();

  const event = events.find((item) => item.id === attendee.eventId);

  addActivity(
    "Time Out Recorded",
    `${attendee.name} completed attendance for "${
      event?.title || "an event"
    }".`
  );

  res.json({
    message: "Time Out recorded.",
    attendee: publicAttendee(attendee),
  });
});

app.delete("/api/attendees/:id", (req, res) => {
  const index = attendees.findIndex((item) => item.id === req.params.id);

  if (index === -1) {
    return res.status(404).json({
      message: "Attendee not found.",
    });
  }

  const attendee = attendees[index];

  attendees.splice(index, 1);

  addActivity(
    "Attendee Removed",
    `${attendee.name} was removed from the attendance list.`
  );

  res.json({
    message: "Attendee removed successfully.",
  });
});

/* =========================================================
   ACTIVITY
   ========================================================= */

app.get("/api/activity", (req, res) => {
  res.json({
    activity: activity.slice(0, 50),
  });
});

/* =========================================================
   REPORT DATA
   ========================================================= */

app.get("/api/reports", (req, res) => {
  res.json({
    events: events.map(publicEvent),
    attendees: attendees.map(publicAttendee),
    summary: {
      totalEvents: events.length,
      activeEvents: events.filter((event) => !event.archived).length,
      archivedEvents: events.filter((event) => event.archived).length,
      totalAttendees: attendees.length,
      timedIn: attendees.filter((item) => item.timeInAt).length,
      completedAttendance: attendees.filter(
        (item) => item.timeInAt && item.timeOutAt
      ).length,
    },
  });
});

/* =========================================================
   404
   ========================================================= */

app.use("/api", (req, res) => {
  res.status(404).json({
    message: "API endpoint not found.",
  });
});

/* =========================================================
   SERVER
   ========================================================= */

app.listen(PORT, () => {
  console.log("======================================");
  console.log("   SCHOOL EVENT MANAGER BACKEND");
  console.log("======================================");
  console.log(`Server running at http://localhost:${PORT}`);
  console.log("Data storage: IN-MEMORY ONLY");
  console.log("======================================");
});