import { useEffect, useMemo, useState } from "react";
import "./App.css";

const API = "http://localhost:5000/api";

const SJC_LOGO =
  "https://sjcbi.edu.ph/wp-content/uploads/2020/07/new-logo-for-seal-1024x1024.png";

const DEFAULT_POSTER =
  "https://static.vecteezy.com/system/resources/previews/011/535/238/non_2x/calendar-illustration-on-a-background-premium-quality-symbols-icons-for-concept-and-graphic-design-vector.jpg";

const emptyEvent = {
  title: "",
  date: "",
  time: "",
  durationDays: 1,
  location: "",
  category: "School",
  organizer: "",
  capacity: "",
  registrationDeadline: "",
  description: "",
  notes: "",
  poster: "",
  attachmentName: "",
  attachmentData: "",
};

function App() {
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("schoolEventUser")) || null;
    } catch {
      return null;
    }
  });

  const [page, setPage] = useState("dashboard");
  const [events, setEvents] = useState([]);
  const [attendees, setAttendees] = useState([]);
  const [activity, setActivity] = useState([]);
  const [dashboard, setDashboard] = useState({});
  const [loading, setLoading] = useState(false);

  const [authMode, setAuthMode] = useState("login");
  const [authForm, setAuthForm] = useState({
    name: "",
    email: "",
    password: "",
  });

  const [eventForm, setEventForm] = useState(emptyEvent);
  const [editingEventId, setEditingEventId] = useState(null);

  const [attendeeForm, setAttendeeForm] = useState({
    name: "",
    eventId: "",
    day: 1,
    attendancePeriod: "AM",
  });

  const [search, setSearch] = useState("");
  const [eventFilter, setEventFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");

  const [calendarDate, setCalendarDate] = useState(new Date());

  const [selectedEvent, setSelectedEvent] = useState(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const [timeOutValues, setTimeOutValues] = useState({});

  const activeEvents = useMemo(
    () => events.filter((event) => !event.archived),
    [events]
  );

  const archivedEvents = useMemo(
    () => events.filter((event) => event.archived),
    [events]
  );

  const upcomingEvents = useMemo(
    () => activeEvents.filter((event) => event.status === "Upcoming"),
    [activeEvents]
  );

  const ongoingEvents = useMemo(
    () => activeEvents.filter((event) => event.status === "Ongoing"),
    [activeEvents]
  );

  const filteredEvents = useMemo(() => {
    return activeEvents.filter((event) => {
      const matchesSearch =
        event.title.toLowerCase().includes(search.toLowerCase()) ||
        event.location.toLowerCase().includes(search.toLowerCase()) ||
        event.category.toLowerCase().includes(search.toLowerCase());

      const matchesCategory =
        eventFilter === "All" || event.category === eventFilter;

      const matchesStatus =
        statusFilter === "All" || event.status === statusFilter;

      return matchesSearch && matchesCategory && matchesStatus;
    });
  }, [activeEvents, search, eventFilter, statusFilter]);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  async function apiRequest(url, options = {}) {
    const response = await fetch(`${API}${url}`, {
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {}),
      },
      ...options,
    });

    let data = {};
    try {
      data = await response.json();
    } catch {
      data = {};
    }

    if (!response.ok) {
      throw new Error(data.message || "Something went wrong.");
    }

    return data;
  }

  async function loadData() {
    setLoading(true);

    try {
      const [eventData, attendeeData, activityData, dashboardData] =
        await Promise.all([
          apiRequest("/events"),
          apiRequest("/attendees"),
          apiRequest("/activity"),
          apiRequest("/dashboard"),
        ]);

      setEvents(eventData.events || []);
      setAttendees(attendeeData.attendees || []);
      setActivity(activityData.activity || []);
      setDashboard(dashboardData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  function showMessage(text) {
    setMessage(text);
    setError("");

    setTimeout(() => {
      setMessage("");
    }, 3500);
  }

  function showError(text) {
    setError(text);
    setMessage("");

    setTimeout(() => {
      setError("");
    }, 5000);
  }

  async function handleAuthSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const endpoint =
        authMode === "login" ? "/auth/login" : "/auth/register";

      const body =
        authMode === "login"
          ? {
              email: authForm.email,
              password: authForm.password,
            }
          : authForm;

      const data = await apiRequest(endpoint, {
        method: "POST",
        body: JSON.stringify(body),
      });

      localStorage.setItem("schoolEventUser", JSON.stringify(data.user));
      setUser(data.user);

      setAuthForm({
        name: "",
        email: "",
        password: "",
      });

      showMessage(
        authMode === "login"
          ? "Welcome back!"
          : "Account created successfully!"
      );
    } catch (err) {
      showError(err.message);
    } finally {
      setLoading(false);
    }
  }

  function logout() {
    localStorage.removeItem("schoolEventUser");
    setUser(null);
    setPage("dashboard");
  }

  function updateEventForm(field, value) {
    setEventForm((current) => ({
      ...current,
      [field]: value,
    }));
  }

  async function readFileAsDataURL(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("Could not read the file."));

      reader.readAsDataURL(file);
    });
  }

  async function handlePosterChange(e) {
    const file = e.target.files?.[0];

    if (!file) return;

    if (!file.type.startsWith("image/")) {
      showError("Please choose an image file for the event poster.");
      return;
    }

    try {
      const data = await readFileAsDataURL(file);
      updateEventForm("poster", data);
    } catch (err) {
      showError(err.message);
    }
  }

  async function handleAttachmentChange(e) {
    const file = e.target.files?.[0];

    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      showError("The file is too large. Please use a file smaller than 8 MB.");
      return;
    }

    try {
      const data = await readFileAsDataURL(file);

      setEventForm((current) => ({
        ...current,
        attachmentName: file.name,
        attachmentData: data,
      }));
    } catch (err) {
      showError(err.message);
    }
  }

  async function saveEvent(e) {
    e.preventDefault();

    if (
      !eventForm.title ||
      !eventForm.date ||
      !eventForm.time ||
      !eventForm.location
    ) {
      showError("Please complete the event name, date, time, and location.");
      return;
    }

    setLoading(true);

    try {
      const body = {
        ...eventForm,
        durationDays: Number(eventForm.durationDays) || 1,
        capacity: Number(eventForm.capacity) || 0,
        createdBy: user?.id,
        createdByName: user?.name,
      };

      if (editingEventId) {
        await apiRequest(`/events/${editingEventId}`, {
          method: "PATCH",
          body: JSON.stringify(body),
        });

        showMessage("Event updated successfully.");
      } else {
        await apiRequest("/events", {
          method: "POST",
          body: JSON.stringify(body),
        });

        showMessage("Event created successfully.");
      }

      setEventForm(emptyEvent);
      setEditingEventId(null);
      setPage("events");

      await loadData();
    } catch (err) {
      showError(err.message);
    } finally {
      setLoading(false);
    }
  }

  function startEditEvent(event) {
    setEditingEventId(event.id);

    setEventForm({
      title: event.title || "",
      date: event.date || "",
      time: event.time || "",
      durationDays: event.durationDays || 1,
      location: event.location || "",
      category: event.category || "School",
      organizer: event.organizer || "",
      capacity: event.capacity || "",
      registrationDeadline: event.registrationDeadline || "",
      description: event.description || "",
      notes: event.notes || "",
      poster: event.poster || "",
      attachmentName: event.attachmentName || "",
      attachmentData: event.attachmentData || "",
    });

    setPage("create");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function archiveEvent(id) {
    if (!window.confirm("Archive this event?")) return;

    try {
      await apiRequest(`/events/${id}/archive`, {
        method: "PATCH",
      });

      showMessage("Event archived.");
      await loadData();
    } catch (err) {
      showError(err.message);
    }
  }

  async function restoreEvent(id) {
    try {
      await apiRequest(`/events/${id}/restore`, {
        method: "PATCH",
      });

      showMessage("Event restored.");
      await loadData();
    } catch (err) {
      showError(err.message);
    }
  }

  async function permanentlyDeleteEvent(id) {
    if (
      !window.confirm(
        "Permanently delete this archived event? This cannot be undone."
      )
    ) {
      return;
    }

    try {
      await apiRequest(`/events/${id}`, {
        method: "DELETE",
      });

      showMessage("Event permanently deleted.");
      await loadData();
    } catch (err) {
      showError(err.message);
    }
  }

  async function addAttendee(e) {
    e.preventDefault();

    if (!attendeeForm.name || !attendeeForm.eventId) {
      showError("Please enter the attendee name and select an event.");
      return;
    }

    try {
      await apiRequest("/attendees", {
        method: "POST",
        body: JSON.stringify({
          ...attendeeForm,
          day: Number(attendeeForm.day),
        }),
      });

      setAttendeeForm({
        name: "",
        eventId: attendeeForm.eventId,
        day: 1,
        attendancePeriod: "AM",
      });

      showMessage("Attendee added. Time In is now available.");
      await loadData();
    } catch (err) {
      showError(err.message);
    }
  }

  async function timeIn(id) {
    try {
      await apiRequest(`/attendees/${id}/time-in`, {
        method: "PATCH",
        body: JSON.stringify({
          timeInAt: new Date().toISOString(),
        }),
      });

      showMessage("Time In recorded.");
      await loadData();
    } catch (err) {
      showError(err.message);
    }
  }

  async function timeOut(id) {
    const value = timeOutValues[id];

    if (!value) {
      showError("Please choose the Time Out date and time first.");
      return;
    }

    try {
      await apiRequest(`/attendees/${id}/time-out`, {
        method: "PATCH",
        body: JSON.stringify({
          timeOutAt: new Date(value).toISOString(),
        }),
      });

      setTimeOutValues((current) => {
        const next = { ...current };
        delete next[id];
        return next;
      });

      showMessage("Time Out recorded.");
      await loadData();
    } catch (err) {
      showError(err.message);
    }
  }

  async function removeAttendee(id) {
    if (!window.confirm("Remove this attendee?")) return;

    try {
      await apiRequest(`/attendees/${id}`, {
        method: "DELETE",
      });

      showMessage("Attendee removed.");
      await loadData();
    } catch (err) {
      showError(err.message);
    }
  }

  function printReport(type) {
    const reportWindow = window.open("", "_blank");

    if (!reportWindow) {
      showError("Please allow pop-ups to print reports.");
      return;
    }

    let content = "";

    if (type === "events") {
      content = `
        <h1>School Event Manager</h1>
        <h2>Events Report</h2>
        <table>
          <tr>
            <th>Event</th>
            <th>Date</th>
            <th>Status</th>
            <th>Location</th>
            <th>Category</th>
          </tr>
          ${events
            .map(
              (event) => `
                <tr>
                  <td>${escapeHTML(event.title)}</td>
                  <td>${formatDate(event.date)}</td>
                  <td>${escapeHTML(event.status)}</td>
                  <td>${escapeHTML(event.location)}</td>
                  <td>${escapeHTML(event.category)}</td>
                </tr>
              `
            )
            .join("")}
        </table>
      `;
    }

    if (type === "attendees") {
      content = `
        <h1>School Event Manager</h1>
        <h2>Attendees Report</h2>
        <table>
          <tr>
            <th>Name</th>
            <th>Event</th>
            <th>Day</th>
            <th>AM/PM</th>
            <th>Time In</th>
            <th>Time Out</th>
          </tr>
          ${attendees
            .map(
              (attendee) => `
                <tr>
                  <td>${escapeHTML(attendee.name)}</td>
                  <td>${escapeHTML(attendee.eventTitle || "Unknown")}</td>
                  <td>Day ${attendee.day}</td>
                  <td>${escapeHTML(attendee.attendancePeriod)}</td>
                  <td>${formatDateTime(attendee.timeInAt)}</td>
                  <td>${formatDateTime(attendee.timeOutAt)}</td>
                </tr>
              `
            )
            .join("")}
        </table>
      `;
    }

    if (type === "summary") {
      content = `
        <h1>School Event Manager</h1>
        <h2>Attendance Summary</h2>
        <div class="summary">
          <p><strong>Total Events:</strong> ${events.length}</p>
          <p><strong>Active Events:</strong> ${activeEvents.length}</p>
          <p><strong>Archived Events:</strong> ${archivedEvents.length}</p>
          <p><strong>Total Attendees:</strong> ${attendees.length}</p>
          <p><strong>Timed In:</strong> ${
            attendees.filter((a) => a.timeInAt).length
          }</p>
          <p><strong>Completed Attendance:</strong> ${
            attendees.filter((a) => a.timeInAt && a.timeOutAt).length
          }</p>
        </div>
      `;
    }

    reportWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>School Event Manager Report</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            padding: 30px;
            color: #222;
          }

          h1 {
            color: #176b3a;
          }

          table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
          }

          th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
          }

          th {
            background: #176b3a;
            color: white;
          }

          .summary {
            font-size: 18px;
            line-height: 1.8;
          }
        </style>
      </head>
      <body>
        ${content}
        <script>
          window.onload = function() {
            window.print();
          };
        </script>
      </body>
      </html>
    `);

    reportWindow.document.close();
  }

  function openEvent(event) {
    setSelectedEvent(event);
  }

  function getAttendeesForEvent(eventId) {
    return attendees.filter((a) => a.eventId === eventId);
  }

  function getEventCapacityText(event) {
    if (!event.capacity) return "Unlimited";

    const count = getAttendeesForEvent(event.id).length;
    return `${count} / ${event.capacity}`;
  }

  function handleDayChange(value) {
    setAttendeeForm((current) => ({
      ...current,
      day: Number(value),
    }));
  }

  function changeMonth(amount) {
    setCalendarDate(
      new Date(
        calendarDate.getFullYear(),
        calendarDate.getMonth() + amount,
        1
      )
    );
  }

  function calendarDays() {
    const year = calendarDate.getFullYear();
    const month = calendarDate.getMonth();

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const days = [];

    for (let i = 0; i < firstDay; i++) {
      days.push(null);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      days.push(day);
    }

    return days;
  }

  function eventsOnCalendarDay(day) {
    if (!day) return [];

    const dateString = `${calendarDate.getFullYear()}-${String(
      calendarDate.getMonth() + 1
    ).padStart(2, "0")}-${String(day).padStart(2, "0")}`;

    return activeEvents.filter((event) => {
      const start = new Date(`${event.date}T00:00:00`);
      const current = new Date(`${dateString}T00:00:00`);
      const end = new Date(start);
      end.setDate(end.getDate() + (event.durationDays || 1) - 1);

      return current >= start && current <= end;
    });
  }

  function renderPage() {
    switch (page) {
      case "dashboard":
        return renderDashboard();

      case "events":
        return renderEvents();

      case "archived":
        return renderArchived();

      case "calendar":
        return renderCalendar();

      case "create":
        return renderCreateEvent();

      case "attendees":
        return renderAttendees();

      case "reports":
        return renderReports();

      default:
        return renderDashboard();
    }
  }

  function renderDashboard() {
    return (
      <>
        <PageHeader
          title="Dashboard"
          subtitle={`Welcome, ${user?.name || "User"}. Here's what's happening with your events.`}
        />

        <div className="stats-grid">
          <StatCard
            icon="📅"
            title="Total Events"
            value={dashboard.totalEvents ?? events.length}
          />

          <StatCard
            icon="⏳"
            title="Upcoming"
            value={dashboard.upcoming ?? upcomingEvents.length}
          />

          <StatCard
            icon="🟢"
            title="Ongoing"
            value={dashboard.ongoing ?? ongoingEvents.length}
          />

          <StatCard
            icon="👥"
            title="Attendees"
            value={dashboard.totalAttendees ?? attendees.length}
          />

          <StatCard
            icon="📦"
            title="Archived"
            value={dashboard.archived ?? archivedEvents.length}
          />
        </div>

        <div className="dashboard-grid">
          <section className="card large-card">
            <div className="card-heading">
              <div>
                <h2>Upcoming Events</h2>
                <p>Your next scheduled school activities.</p>
              </div>

              <button
                className="text-button"
                onClick={() => setPage("events")}
              >
                View All
              </button>
            </div>

            {upcomingEvents.length === 0 ? (
              <EmptyState
                icon="📅"
                title="No upcoming events"
                text="Create an event to see it here."
              />
            ) : (
              <div className="event-card-grid">
                {upcomingEvents.slice(0, 4).map((event) => (
                  <EventCard
                    key={event.id}
                    event={event}
                    attendeeCount={getAttendeesForEvent(event.id).length}
                    onClick={() => openEvent(event)}
                  />
                ))}
              </div>
            )}
          </section>

          <section className="card">
            <div className="card-heading">
              <div>
                <h2>Recent Activity</h2>
                <p>Latest actions in the system.</p>
              </div>
            </div>

            <div className="activity-list">
              {activity.length === 0 ? (
                <EmptyState
                  icon="📝"
                  title="No activity yet"
                  text="Your recent activity will appear here."
                />
              ) : (
                activity.slice(0, 8).map((item) => (
                  <div className="activity-item" key={item.id}>
                    <div className="activity-dot" />
                    <div>
                      <strong>{item.action}</strong>
                      <p>{item.details}</p>
                      <small>{formatDateTime(item.createdAt)}</small>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>
        </div>

        <section className="card">
          <div className="card-heading">
            <div>
              <h2>Attendance Overview</h2>
              <p>Current attendance activity.</p>
            </div>

            <button
              className="text-button"
              onClick={() => setPage("attendees")}
            >
              Manage Attendance
            </button>
          </div>

          <div className="attendance-overview">
            <div>
              <span className="overview-number">
                {attendees.filter((a) => a.timeInAt).length}
              </span>
              <span>Timed In</span>
            </div>

            <div>
              <span className="overview-number">
                {attendees.filter((a) => a.timeInAt && a.timeOutAt).length}
              </span>
              <span>Completed</span>
            </div>

            <div>
              <span className="overview-number">
                {attendees.filter((a) => !a.timeInAt).length}
              </span>
              <span>Waiting for Time In</span>
            </div>
          </div>
        </section>
      </>
    );
  }

  function renderEvents() {
    return (
      <>
        <PageHeader
          title="Events"
          subtitle="Manage all active school events."
          action={
            <button className="primary-button" onClick={() => setPage("create")}>
              + Create Event
            </button>
          }
        />

        <section className="card">
          <div className="filters">
            <input
              className="search-input"
              placeholder="Search events..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />

            <select
              value={eventFilter}
              onChange={(e) => setEventFilter(e.target.value)}
            >
              <option value="All">All Categories</option>
              <option value="School">School</option>
              <option value="Academic">Academic</option>
              <option value="Sports">Sports</option>
              <option value="Religious">Religious</option>
              <option value="Meeting">Meeting</option>
              <option value="Other">Other</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="All">All Statuses</option>
              <option value="Upcoming">Upcoming</option>
              <option value="Ongoing">Ongoing</option>
              <option value="Finished">Finished</option>
            </select>
          </div>

          {filteredEvents.length === 0 ? (
            <EmptyState
              icon="📅"
              title="No events found"
              text="Try changing your search or create a new event."
            />
          ) : (
            <div className="event-table-wrapper">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Event</th>
                    <th>Date</th>
                    <th>Duration</th>
                    <th>Location</th>
                    <th>Status</th>
                    <th>Attendees</th>
                    <th>Actions</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredEvents.map((event) => (
                    <tr key={event.id}>
                      <td>
                        <div className="table-event">
                          <img
                            src={event.poster || DEFAULT_POSTER}
                            alt=""
                          />
                          <div>
                            <strong>{event.title}</strong>
                            <span>{event.category}</span>
                          </div>
                        </div>
                      </td>

                      <td>{formatDate(event.date)}</td>

                      <td>
                        {event.durationDays}{" "}
                        {event.durationDays === 1 ? "day" : "days"}
                      </td>

                      <td>{event.location}</td>

                      <td>
                        <StatusBadge status={event.status} />
                      </td>

                      <td>{getEventCapacityText(event)}</td>

                      <td>
                        <div className="action-buttons">
                          <button
                            className="small-button"
                            onClick={() => openEvent(event)}
                          >
                            View
                          </button>

                          <button
                            className="small-button"
                            onClick={() => startEditEvent(event)}
                          >
                            Edit
                          </button>

                          <button
                            className="small-button danger"
                            onClick={() => archiveEvent(event.id)}
                          >
                            Archive
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  }

  function renderArchived() {
    return (
      <>
        <PageHeader
          title="Archived Events"
          subtitle="Restore or permanently delete archived events."
        />

        <section className="card">
          {archivedEvents.length === 0 ? (
            <EmptyState
              icon="📦"
              title="No archived events"
              text="Archived events will appear here."
            />
          ) : (
            <div className="event-table-wrapper">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Event</th>
                    <th>Date</th>
                    <th>Location</th>
                    <th>Category</th>
                    <th>Actions</th>
                  </tr>
                </thead>

                <tbody>
                  {archivedEvents.map((event) => (
                    <tr key={event.id}>
                      <td>
                        <div className="table-event">
                          <img
                            src={event.poster || DEFAULT_POSTER}
                            alt=""
                          />
                          <div>
                            <strong>{event.title}</strong>
                            <span>Archived</span>
                          </div>
                        </div>
                      </td>

                      <td>{formatDate(event.date)}</td>
                      <td>{event.location}</td>
                      <td>{event.category}</td>

                      <td>
                        <div className="action-buttons">
                          <button
                            className="small-button"
                            onClick={() => restoreEvent(event.id)}
                          >
                            Restore
                          </button>

                          <button
                            className="small-button danger"
                            onClick={() =>
                              permanentlyDeleteEvent(event.id)
                            }
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  }

  function renderCalendar() {
    const monthName = calendarDate.toLocaleString("en-US", {
      month: "long",
      year: "numeric",
    });

    return (
      <>
        <PageHeader
          title="Calendar"
          subtitle="See your school events by date."
        />

        <section className="card calendar-card">
          <div className="calendar-header">
            <button
              className="small-button"
              onClick={() => changeMonth(-1)}
            >
              ← Previous
            </button>

            <h2>{monthName}</h2>

            <button
              className="small-button"
              onClick={() => changeMonth(1)}
            >
              Next →
            </button>
          </div>

          <div className="calendar-weekdays">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(
              (day) => (
                <div key={day}>{day}</div>
              )
            )}
          </div>

          <div className="calendar-grid">
            {calendarDays().map((day, index) => {
              const dayEvents = eventsOnCalendarDay(day);

              return (
                <div
                  className={`calendar-day ${day ? "" : "empty"}`}
                  key={index}
                >
                  {day && (
                    <>
                      <strong>{day}</strong>

                      <div className="calendar-events">
                        {dayEvents.map((event) => (
                          <button
                            key={event.id}
                            onClick={() => openEvent(event)}
                            title={event.title}
                          >
                            {event.title}
                          </button>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      </>
    );
  }

  function renderCreateEvent() {
    return (
      <>
        <PageHeader
          title={editingEventId ? "Edit Event" : "Create Event"}
          subtitle={
            editingEventId
              ? "Update the event information."
              : "Create a new school event."
          }
        />

        <form className="card event-form" onSubmit={saveEvent}>
          <div className="form-section">
            <h2>Basic Information</h2>

            <div className="form-grid">
              <label className="full">
                Event Name *
                <input
                  value={eventForm.title}
                  onChange={(e) => updateEventForm("title", e.target.value)}
                  placeholder="e.g. Intramurals 2026"
                  required
                />
              </label>

              <label>
                Date *
                <input
                  type="date"
                  value={eventForm.date}
                  onChange={(e) => updateEventForm("date", e.target.value)}
                  required
                />
              </label>

              <label>
                Start Time *
                <input
                  type="time"
                  value={eventForm.time}
                  onChange={(e) => updateEventForm("time", e.target.value)}
                  required
                />
              </label>

              <label>
                Duration
                <select
                  value={eventForm.durationDays}
                  onChange={(e) =>
                    updateEventForm("durationDays", Number(e.target.value))
                  }
                >
                  <option value={1}>1 Day</option>
                  <option value={2}>2 Days</option>
                  <option value={3}>3 Days</option>
                </select>
              </label>

              <label>
                Location *
                <input
                  value={eventForm.location}
                  onChange={(e) =>
                    updateEventForm("location", e.target.value)
                  }
                  placeholder="e.g. School Gymnasium"
                  required
                />
              </label>

              <label>
                Category
                <select
                  value={eventForm.category}
                  onChange={(e) =>
                    updateEventForm("category", e.target.value)
                  }
                >
                  <option>School</option>
                  <option>Academic</option>
                  <option>Sports</option>
                  <option>Religious</option>
                  <option>Meeting</option>
                  <option>Other</option>
                </select>
              </label>

              <label>
                Organizer
                <input
                  value={eventForm.organizer}
                  onChange={(e) =>
                    updateEventForm("organizer", e.target.value)
                  }
                  placeholder="Organizer or office"
                />
              </label>

              <label>
                Capacity
                <input
                  type="number"
                  min="0"
                  value={eventForm.capacity}
                  onChange={(e) =>
                    updateEventForm("capacity", e.target.value)
                  }
                  placeholder="0 = unlimited"
                />
              </label>

              <label>
                Registration Deadline
                <input
                  type="date"
                  value={eventForm.registrationDeadline}
                  onChange={(e) =>
                    updateEventForm(
                      "registrationDeadline",
                      e.target.value
                    )
                  }
                />
              </label>
            </div>
          </div>

          <div className="form-section">
            <h2>Description</h2>

            <label>
              Event Description
              <textarea
                rows="5"
                value={eventForm.description}
                onChange={(e) =>
                  updateEventForm("description", e.target.value)
                }
                placeholder="Describe the event..."
              />
            </label>

            <label>
              Additional Notes
              <textarea
                rows="4"
                value={eventForm.notes}
                onChange={(e) => updateEventForm("notes", e.target.value)}
                placeholder="Dress code, reminders, requirements, etc."
              />
            </label>
          </div>

          <div className="form-section">
            <h2>Event Poster</h2>

            <div className="upload-area">
              <input
                id="poster-upload"
                type="file"
                accept="image/*"
                onChange={handlePosterChange}
              />

              <label htmlFor="poster-upload" className="upload-label">
                <span>🖼️</span>
                <strong>Choose Event Poster</strong>
                <small>PNG, JPG, JPEG, WEBP</small>
              </label>

              <div className="poster-preview">
                <img
                  src={eventForm.poster || DEFAULT_POSTER}
                  alt="Event poster preview"
                />
              </div>
            </div>
          </div>

          <div className="form-section">
            <h2>Concept Paper / Related File</h2>

            <div className="upload-area compact-upload">
              <input
                id="attachment-upload"
                type="file"
                onChange={handleAttachmentChange}
              />

              <label
                htmlFor="attachment-upload"
                className="upload-label"
              >
                <span>📎</span>
                <strong>Choose File</strong>
                <small>Maximum size: 8 MB</small>
              </label>

              {eventForm.attachmentName && (
                <div className="selected-file">
                  <span>📄</span>
                  <strong>{eventForm.attachmentName}</strong>
                  <button
                    type="button"
                    onClick={() =>
                      setEventForm((current) => ({
                        ...current,
                        attachmentName: "",
                        attachmentData: "",
                      }))
                    }
                  >
                    Remove
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="form-actions">
            <button
              type="button"
              className="secondary-button"
              onClick={() => {
                setEventForm(emptyEvent);
                setEditingEventId(null);
                setPage("events");
              }}
            >
              Cancel
            </button>

            <button className="primary-button" disabled={loading}>
              {loading
                ? "Saving..."
                : editingEventId
                ? "Update Event"
                : "Create Event"}
            </button>
          </div>
        </form>
      </>
    );
  }

  function renderAttendees() {
    return (
      <>
        <PageHeader
          title="Attendees"
          subtitle="Record attendance using Time In first, then Time Out."
        />

        <section className="card">
          <div className="card-heading">
            <div>
              <h2>Add Attendee</h2>
              <p>Time In will only become available after the attendee is listed.</p>
            </div>
          </div>

          <form className="attendee-form" onSubmit={addAttendee}>
            <label>
              Attendee Name
              <input
                value={attendeeForm.name}
                onChange={(e) =>
                  setAttendeeForm((current) => ({
                    ...current,
                    name: e.target.value,
                  }))
                }
                placeholder="Full name"
              />
            </label>

            <label>
              Event
              <select
                value={attendeeForm.eventId}
                onChange={(e) =>
                  setAttendeeForm((current) => ({
                    ...current,
                    eventId: e.target.value,
                    day: 1,
                  }))
                }
              >
                <option value="">Select event</option>

                {activeEvents.map((event) => (
                  <option value={event.id} key={event.id}>
                    {event.title}
                  </option>
                ))}
              </select>
            </label>

            <label>
              Day
              <select
                value={attendeeForm.day}
                onChange={(e) => handleDayChange(e.target.value)}
              >
                {[1, 2, 3]
                  .filter((day) => {
                    const event = activeEvents.find(
                      (item) => item.id === attendeeForm.eventId
                    );

                    return event ? day <= event.durationDays : day === 1;
                  })
                  .map((day) => (
                    <option value={day} key={day}>
                      Day {day}
                    </option>
                  ))}
              </select>
            </label>

            <label>
              Period
              <select
                value={attendeeForm.attendancePeriod}
                onChange={(e) =>
                  setAttendeeForm((current) => ({
                    ...current,
                    attendancePeriod: e.target.value,
                  }))
                }
              >
                <option value="AM">AM</option>
                <option value="PM">PM</option>
              </select>
            </label>

            <button className="primary-button">Add Attendee</button>
          </form>
        </section>

        <section className="card">
          <div className="card-heading">
            <div>
              <h2>Attendance List</h2>
              <p>{attendees.length} attendance record(s)</p>
            </div>

            <input
              className="search-input attendance-search"
              placeholder="Search attendee..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="event-table-wrapper">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Event</th>
                  <th>Day</th>
                  <th>Period</th>
                  <th>Time In</th>
                  <th>Time Out</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {attendees
                  .filter((attendee) =>
                    attendee.name
                      .toLowerCase()
                      .includes(search.toLowerCase())
                  )
                  .map((attendee) => (
                    <tr key={attendee.id}>
                      <td>
                        <strong>{attendee.name}</strong>
                      </td>

                      <td>{attendee.eventTitle || "Unknown Event"}</td>

                      <td>Day {attendee.day}</td>

                      <td>{attendee.attendancePeriod}</td>

                      <td>
                        {attendee.timeInAt
                          ? formatDateTime(attendee.timeInAt)
                          : (
                            <button
                              className="small-button success"
                              onClick={() => timeIn(attendee.id)}
                            >
                              Time In
                            </button>
                          )}
                      </td>

                      <td>
                        {!attendee.timeInAt ? (
                          <span className="muted">
                            Time In first
                          </span>
                        ) : attendee.timeOutAt ? (
                          formatDateTime(attendee.timeOutAt)
                        ) : (
                          <div className="timeout-control">
                            <input
                              type="datetime-local"
                              value={timeOutValues[attendee.id] || ""}
                              onChange={(e) =>
                                setTimeOutValues((current) => ({
                                  ...current,
                                  [attendee.id]: e.target.value,
                                }))
                              }
                            />

                            <button
                              className="small-button"
                              onClick={() => timeOut(attendee.id)}
                            >
                              Time Out
                            </button>
                          </div>
                        )}
                      </td>

                      <td>
                        {!attendee.timeInAt ? (
                          <span className="attendance-status waiting">
                            Not Timed In
                          </span>
                        ) : !attendee.timeOutAt ? (
                          <span className="attendance-status present">
                            Present
                          </span>
                        ) : (
                          <span className="attendance-status completed">
                            Completed
                          </span>
                        )}
                      </td>

                      <td>
                        <button
                          className="small-button danger"
                          onClick={() => removeAttendee(attendee.id)}
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </section>
      </>
    );
  }

  function renderReports() {
    return (
      <>
        <PageHeader
          title="Reports"
          subtitle="Print useful reports for school events."
        />

        <div className="report-grid">
          <ReportCard
            icon="📅"
            title="Events Report"
            text="Print all events, their dates, locations, categories, and statuses."
            button="Print Events"
            onClick={() => printReport("events")}
          />

          <ReportCard
            icon="👥"
            title="Attendees Report"
            text="Print attendee names, event attendance, Time In, and Time Out."
            button="Print Attendees"
            onClick={() => printReport("attendees")}
          />

          <ReportCard
            icon="📊"
            title="Attendance Summary"
            text="Print a summary of events and attendance activity."
            button="Print Summary"
            onClick={() => printReport("summary")}
          />
        </div>
      </>
    );
  }

  if (!user) {
    return (
      <div className="auth-page">
        <div className="auth-card">
          <div className="auth-logo">
            <img src={SJC_LOGO} alt="SJCBI Logo" />
          </div>

          <h1>School Event Manager</h1>
          <p className="auth-subtitle">
            Saint Joseph's College of Baggao
          </p>

          <div className="auth-tabs">
            <button
              className={authMode === "login" ? "active" : ""}
              onClick={() => setAuthMode("login")}
            >
              Login
            </button>

            <button
              className={authMode === "register" ? "active" : ""}
              onClick={() => setAuthMode("register")}
            >
              Register
            </button>
          </div>

          {error && <div className="alert error">{error}</div>}
          {message && <div className="alert success-alert">{message}</div>}

          <form onSubmit={handleAuthSubmit}>
            {authMode === "register" && (
              <label>
                Full Name
                <input
                  value={authForm.name}
                  onChange={(e) =>
                    setAuthForm((current) => ({
                      ...current,
                      name: e.target.value,
                    }))
                  }
                  placeholder="Your name"
                  required
                />
              </label>
            )}

            <label>
              Email
              <input
                type="email"
                value={authForm.email}
                onChange={(e) =>
                  setAuthForm((current) => ({
                    ...current,
                    email: e.target.value,
                  }))
                }
                placeholder="you@example.com"
                required
              />
            </label>

            <label>
              Password
              <input
                type="password"
                value={authForm.password}
                onChange={(e) =>
                  setAuthForm((current) => ({
                    ...current,
                    password: e.target.value,
                  }))
                }
                placeholder="Password"
                required
              />
            </label>

            <button className="primary-button auth-submit" disabled={loading}>
              {loading
                ? "Please wait..."
                : authMode === "login"
                ? "Login"
                : "Create Account"}
            </button>
          </form>

          <p className="auth-footer">
            School Event Manager • SJCBI
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <img src={SJC_LOGO} alt="SJCBI Logo" />

          <div>
            <h2>School Event Manager</h2>
            <span>SJCBI</span>
          </div>
        </div>

        <nav className="sidebar-nav">
          <NavItem
            icon="⌂"
            label="Dashboard"
            active={page === "dashboard"}
            onClick={() => setPage("dashboard")}
          />

          <NavItem
            icon="📅"
            label="Events"
            active={page === "events"}
            onClick={() => setPage("events")}
          />

          <NavItem
            icon="➕"
            label="Create Event"
            active={page === "create"}
            onClick={() => {
              setEditingEventId(null);
              setEventForm(emptyEvent);
              setPage("create");
            }}
          />

          <NavItem
            icon="👥"
            label="Attendees"
            active={page === "attendees"}
            onClick={() => setPage("attendees")}
          />

          <NavItem
            icon="🗓️"
            label="Calendar"
            active={page === "calendar"}
            onClick={() => setPage("calendar")}
          />

          <NavItem
            icon="📦"
            label="Archived Events"
            active={page === "archived"}
            onClick={() => setPage("archived")}
          />

          <NavItem
            icon="📊"
            label="Reports"
            active={page === "reports"}
            onClick={() => setPage("reports")}
          />
        </nav>

        <div className="sidebar-bottom">
          <div className="user-box">
            <div className="user-avatar">
              {(user.name || "U").charAt(0).toUpperCase()}
            </div>

            <div>
              <strong>{user.name}</strong>
              <span>{user.role || "User"}</span>
            </div>
          </div>

          <button className="logout-button" onClick={logout}>
            ⇥ Logout
          </button>
        </div>
      </aside>

      <main className="main-content">
        {message && <div className="global-alert success-alert">{message}</div>}
        {error && <div className="global-alert error">{error}</div>}

        {loading && (
          <div className="loading-bar">
            <span />
          </div>
        )}

        {renderPage()}
      </main>

      {selectedEvent && (
        <EventModal
          event={selectedEvent}
          attendeeCount={getAttendeesForEvent(selectedEvent.id).length}
          onClose={() => setSelectedEvent(null)}
          onEdit={() => {
            startEditEvent(selectedEvent);
            setSelectedEvent(null);
          }}
        />
      )}
    </div>
  );
}

function PageHeader({ title, subtitle, action }) {
  return (
    <div className="page-header">
      <div>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>

      {action && action}
    </div>
  );
}

function StatCard({ icon, title, value }) {
  return (
    <div className="stat-card">
      <div className="stat-icon">{icon}</div>

      <div>
        <span>{title}</span>
        <strong>{value}</strong>
      </div>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }) {
  return (
    <button className={`nav-item ${active ? "active" : ""}`} onClick={onClick}>
      <span>{icon}</span>
      {label}
    </button>
  );
}

function EventCard({ event, attendeeCount, onClick }) {
  return (
    <button className="event-card" onClick={onClick}>
      <div className="event-card-image">
        <img src={event.poster || DEFAULT_POSTER} alt="" />

        <StatusBadge status={event.status} />
      </div>

      <div className="event-card-content">
        <span className="event-category">{event.category}</span>

        <h3>{event.title}</h3>

        <p>📅 {formatDate(event.date)}</p>
        <p>📍 {event.location}</p>
        <p>👥 {attendeeCount} attendee(s)</p>
      </div>
    </button>
  );
}

function StatusBadge({ status }) {
  return (
    <span className={`status-badge ${status.toLowerCase()}`}>
      {status}
    </span>
  );
}

function EmptyState({ icon, title, text }) {
  return (
    <div className="empty-state">
      <div>{icon}</div>
      <h3>{title}</h3>
      <p>{text}</p>
    </div>
  );
}

function ReportCard({ icon, title, text, button, onClick }) {
  return (
    <div className="report-card">
      <div className="report-icon">{icon}</div>
      <h2>{title}</h2>
      <p>{text}</p>

      <button className="primary-button" onClick={onClick}>
        {button}
      </button>
    </div>
  );
}

function EventModal({ event, attendeeCount, onClose, onEdit }) {
  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <div
        className="modal"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <button className="modal-close" onClick={onClose}>
          ×
        </button>

        <img
          className="modal-poster"
          src={event.poster || DEFAULT_POSTER}
          alt={event.title}
        />

        <div className="modal-content">
          <div className="modal-title-row">
            <div>
              <span className="event-category">{event.category}</span>
              <h2>{event.title}</h2>
            </div>

            <StatusBadge status={event.status} />
          </div>

          <div className="event-info-grid">
            <InfoItem label="Date" value={formatDate(event.date)} />
            <InfoItem label="Start Time" value={formatTime(event.time)} />
            <InfoItem
              label="Duration"
              value={`${event.durationDays} day(s)`}
            />
            <InfoItem label="Location" value={event.location} />
            <InfoItem
              label="Organizer"
              value={event.organizer || "Not specified"}
            />
            <InfoItem
              label="Attendees"
              value={
                event.capacity
                  ? `${attendeeCount} / ${event.capacity}`
                  : `${attendeeCount} / Unlimited`
              }
            />
          </div>

          {event.description && (
            <div className="modal-section">
              <h3>Description</h3>
              <p>{event.description}</p>
            </div>
          )}

          {event.notes && (
            <div className="modal-section">
              <h3>Notes</h3>
              <p>{event.notes}</p>
            </div>
          )}

          {event.attachmentData && (
            <div className="modal-section">
              <h3>Related File</h3>

              <a
                className="file-link"
                href={event.attachmentData}
                download={event.attachmentName}
              >
                📎 {event.attachmentName}
              </a>
            </div>
          )}

          <div className="modal-actions">
            <button className="secondary-button" onClick={onClose}>
              Close
            </button>

            <button className="primary-button" onClick={onEdit}>
              Edit Event
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoItem({ label, value }) {
  return (
    <div className="info-item">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function formatDate(date) {
  if (!date) return "—";

  const value = new Date(`${date}T00:00:00`);

  if (Number.isNaN(value.getTime())) return date;

  return value.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function formatTime(time) {
  if (!time) return "—";

  const value = new Date(`2000-01-01T${time}`);

  if (Number.isNaN(value.getTime())) return time;

  return value.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
}

function formatDateTime(value) {
  if (!value) return "—";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return "—";

  return date.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function escapeHTML(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

export default App;